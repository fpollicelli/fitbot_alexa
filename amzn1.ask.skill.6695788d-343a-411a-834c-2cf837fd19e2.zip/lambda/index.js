  // This sample demonstrates handling intents from an Alexa skill using the Alexa Skills Kit SDK (v2).
  // Please visit https://alexa.design/cookbook for additional examples on implementing slots, dialog management,
  // session persistence, api calls, and more.

  /********** BINDING CON IL DB***********/
  const Alexa = require('ask-sdk-core');
  const admin = require("firebase-admin");
  const serviceAccount = require("firebase.json");
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    databaseURL: "https://prova-ihhrah.firebaseio.com"
  });
  const db = admin.firestore();
  /************************************/
  var dialogflowAgentDoc = 0;
  var  dialogflowAgentDott = 0;
  var autCode = 0;
  var nome = '';
  /**************************************/
 
/*************************************/

function supportsDisplay(handlerInput) {
  const hasDisplay =
    handlerInput.requestEnvelope.context &&
    handlerInput.requestEnvelope.context.System &&
    handlerInput.requestEnvelope.context.System.device &&
    handlerInput.requestEnvelope.context.System.device.supportedInterfaces &&
    handlerInput.requestEnvelope.context.System.device.supportedInterfaces.Display;
  return hasDisplay;
}
  const LaunchRequestHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'LaunchRequest';
      },
      handle(handlerInput) {
              
         const speakOutput = "Ciao, mi chiamo Fit Bot, sono un assistente virtuale creato per assisterti durante il tuo percorso nutrizionale. Se sei registrato alla piattaforma, dimmi il tuo codice cliente, così potrò accedere alla tua dieta. Se non sei registrato, puoi comunque accedere a tutte le mie funzionalità.";
         
         const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
              .speak(speakOutput)
              .reprompt(speakOutput)
              .getResponse();
              }
  };

  const piacereIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'piacereIntent';
      },
      handle(handlerInput) {
          nome = Alexa.getSlotValue(handlerInput.requestEnvelope,'nome');
          var speakOutput = 'ok';
          if(typeof nome === 'undefined'){
          speakOutput ='Il piacere è tutto mio!';
          }else{
           speakOutput = 'Il piacere è tutto mio, '+nome;
          }
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
              .speak(speakOutput)
              .reprompt(speakOutput)
              .getResponse();
      }
  };
  
  
  const haifameIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'haifameIntent';
      },
      handle(handlerInput) {
          var cibo = Alexa.getSlotValue(handlerInput.requestEnvelope,'cibo');
          var speakOutput = '';
          if(typeof cibo === 'undefined'){
          speakOutput ='Ho sempre fame, ma attendo il mio pasto sgarro!';
          }else{
           speakOutput = 'Se ho voglia di ' + cibo + '? Certo! Ma attendo il mio pasto sgarro!';
          }
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
              .speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };
  
  
  
  
  const AutIntentHandler ={
      canHandle(handlerInput) {
      return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AutIntent';
    },
     handle(handlerInput) {
      autCode = Alexa.getSlotValue(handlerInput.requestEnvelope,'autCode');
      if(typeof autCode === 'undefined'|| autCode === 0){
          
          const speakOutput = 'Okay, non preoccuparti. In tal caso posso darti informazioni generali, come la quantità di acqua da assumere, quali cibi sostituire nella tua alimentazione, calcolare il tuo indice di massa corporea, darti consigli per rimanere in forma, suggerirti alimentazioni per condizioni particolari e per alleviare sintomi di disturbi fisici. ';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
        .speak(speakOutput)
        .reprompt(' ')
        .getResponse();
      }else{
      dialogflowAgentDoc = db.collection('dialogflow').doc(autCode); //LINEA AGGIUNTA DALL'ULTIMO DEPLOY FUNZIONANTE
      return dialogflowAgentDoc.get()
              .then(doc => {
      const speakOutput = 'Bentornato, ' +  doc.data().nome +  ', spero che tu stia bene. Come posso aiutarti?';
      
       const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
        .speak(speakOutput)
        .reprompt(' ')
        .getResponse();
              });
      }
      }
  };

  const NonStoBeneIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'NonStoBeneIntent';
      },
      handle(handlerInput) {
          if(typeof autCode === 'undefined' || autCode === 0){
          const speakOutput = 'Se pensi che il tuo malessere sia di lieve entità, posso consigliare alimenti per le seguenti problematiche: intolleranza al lattosio, intolleranza al glutine, colesterolo alto, acne, insonnia, sonnolenza, gas intestinali, gonfiore addominale.';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
        .speak(speakOutput)
        .reprompt(' ')
        .getResponse();
      }else{
      return dialogflowAgentDoc.get()
              .then(doc => {
               let e = doc.data().email;
               const dialogflowAgentDott = db.collection('users').doc(e)
       return dialogflowAgentDott.get()
              .then(doc => {
          let nome = doc.data().cognome;
           let telefono = doc.data().telefono;
           var res = telefono.split("");
          const speakOutput = 'Se il tuo malessere è da imputarsi alla dieta, ti ricordo che il numero del Dottor ' + nome + ' è ' + res[0]+' ' + res[1]+' ' +res[2]+' ' +res[3]+' ' +res[4]+' ' +res[5]+' ' +res[6]+' ' +res[7]+' ' +res[8]+' ' +res[9]+'. Potresti chiamarlo per esporre meglio i tuoi sintomi. Se invece pensi che il tuo malessere sia di lieve entità, posso consigliare alimenti per le seguenti problematiche: intolleranza al lattosio, intolleranza al glutine, colesterolo alto, acne, insonnia, sonnolenza, gas intestinali, gonfiore addominale.';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
              .speak(speakOutput)
              .reprompt(' ')
              .getResponse();
              })});}}
  };
   
  const GetPesoIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'GetPesoIntent';
      },
      handle(handlerInput) {
          const pesata = Alexa.getSlotValue(handlerInput.requestEnvelope,'pesata');
           if(typeof autCode === 'undefined' || autCode === 0){
          const speakOutput = 'Mi dispiace, ma non posso aggiornare il tuo peso perchè non sei in possesso di una dieta sulla piattaforma. Contatta il tuo nutrizionista per ottenerne una.';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
        .speak(speakOutput)
        
        .reprompt(' ')
        .getResponse();
      }else{
      return dialogflowAgentDoc.get()
              .then(doc => {
      let nome = doc.data().nome;
      let peso_obbiettivo = doc.data().peso_obbiettivo;
      let vecchio_peso = doc.data().peso_attuale;
     var speakOutput ='ok';
     
     db.collection('dialogflow').doc(autCode).update({
         peso_attuale: pesata
     })
     if(pesata === peso_obbiettivo){
     speakOutput = 'Complimenti ' + nome + ', hai raggiunto il tuo obiettivo peso di '+peso_obbiettivo+ ' chili, continua così! Il tuo peso precedente era di '+vecchio_peso+' chili.';
     }else{
         speakOutput = 'Okay ' + nome + ', ho aggiornato il tuo peso sulla piattaforma. Ti ricordo che il tuo obiettivo peso è di '+peso_obbiettivo+ ' chili. Il tuo peso precedente era di '+vecchio_peso+' chili.';
     }
      
   const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
              .speak(speakOutput)
              .reprompt(speakOutput)
              .getResponse();
      
              });
      }
      }
  };

  const fabbisognocaloricoIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'fabbisognocaloricoIntent';
      },
      handle(handlerInput) {
          const peso = Alexa.getSlotValue(handlerInput.requestEnvelope,'peso');
          const allenamento = Alexa.getSlotValue(handlerInput.requestEnvelope,'allenamento');
          var libr = parseInt(peso)*2.2;
          const allen = parseInt(allenamento);
          var molt;
         switch(allen){
           case 'una','uno','un','Uno','Una','Un',1:
                molt = 11;
                 break;
          case 'due','Due',2:
               molt = 12;
                 break;
          case 'tre','Tre',3:
              molt = 13;
                 break;
            case 'quattro','Quattro',4:
                molt = 14;
                 break;
           case 'cinque','Cinque',5:
               molt = 15;
                 break;
            case 'sei','Sei',6:
                molt = 17;
                 break;
          case 'sette','Sette',7:
              molt = 19;
                 break;
                 default:
                 molt = 10;
                 break;
         }
         
      var fabbisogno = libr * molt;
      fabbisogno = parseInt(fabbisogno);
     var speakOutput ='Il tuo fabbisogno totale giornaliero è di '+fabbisogno+' calorie. Assicurati di assumere la giusta quantità!';

   const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
              .speak(speakOutput)
              .reprompt(speakOutput)
              .getResponse();
     
      }
  };


  const PesaturaGuestIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'PesaturaGuestIntent';
      },
      handle(handlerInput) {
          const peso = Alexa.getSlotValue(handlerInput.requestEnvelope,'peso');
          const sesso = Alexa.getSlotValue(handlerInput.requestEnvelope,'sesso');
          const altezza = Alexa.getSlotValue(handlerInput.requestEnvelope,'altezza');
          const eta = Alexa.getSlotValue(handlerInput.requestEnvelope,'eta');
           
     

     if (sesso === 'uomo' || sesso === 'Uomo') {
       let par1 = (13.7 * peso);
       let par2 = (5 * altezza);
       let par3 = (6.75 * eta);
     }else{
     if (sesso === 'donna' || sesso === 'Donna') {
       let par1 = (13.7 * peso);
       let par2 = (5 * altezza);
       let par3 = (6.75 * eta);
     } 
        }
      
     let altezzaInM = altezza/100;
     let par4 = Math.pow(altezzaInM, 2);
     let Imc = (peso/par4).toFixed(2);
     var speakOutput ='ok';
     
     if (Imc < 16.00) {
       speakOutput= 'L\u0027 indice di massa corporea (abbreviato IMC o BMI, dall\u0027 inglese body mass index) è un dato biomètrico, espresso come rapporto tra peso e quadrato dell\u0027 altezza di un individuo ed è utilizzato come un indicatore dello stato di peso forma. Il tuo IMC è di '+Imc+', sei in una situazione di grave magrezza e ciò comporta grossi rischi per la tua salute. Segui attentamente la dieta e riusciremo insieme a tornare in forma! Posso aiutarti in qualcos altro?';
  }
  if (Imc >= 16.00 && Imc <= 18.49) {
       speakOutput= 'L\u0027 indice di massa corporea (abbreviato IMC o BMI, dall\u0027 inglese body mass index) è un dato biomètrico, espresso come rapporto tra peso e quadrato dell\u0027 altezza di un individuo ed è utilizzato come un indicatore dello stato di peso forma. Il tuo IMC è di '+Imc+', sei sottopeso. Segui attentamente la dieta e riusciremo insieme a tornare in forma! Posso aiutarti in qualcos altro?';
  }
  if (Imc >= 18.50 && Imc <= 24.99) {
         
          speakOutput= 'L\u0027 indice di massa corporea (abbreviato IMC o BMI, dall\u0027 inglese body mass index) è un dato biomètrico, espresso come rapporto tra peso e quadrato dell\u0027 altezza di un individuo ed è utilizzato come un indicatore dello stato di peso forma. Il tuo IMC è di '+Imc+', sei normopeso. Segui attentamente la dieta e riusciremo insieme a tornare in forma! Posso aiutarti in qualcos altro?';
      
      }
  if (Imc >= 25.00 && Imc <= 29.99) {
     
       speakOutput= 'L\u0027 indice di massa corporea (abbreviato IMC o BMI, dall\u0027 inglese body mass index) è un dato biomètrico, espresso come rapporto tra peso e quadrato dell\u0027 altezza di un individuo ed è utilizzato come un indicatore dello stato di peso forma. Il tuo IMC è di '+Imc+', sei leggermente in sovrappeso. Segui attentamente la dieta e riusciremo insieme a tornare in forma! Posso aiutarti in qualcos altro?';
  }
  if (Imc >= 30.00 && Imc <= 34.99) {
       speakOutput= 'L\u0027 indice di massa corporea (abbreviato IMC o BMI, dall\u0027 inglese body mass index) è un dato biomètrico, espresso come rapporto tra peso e quadrato dell\u0027 altezza di un individuo ed è utilizzato come un indicatore dello stato di peso forma. Il tuo IMC è di '+Imc+', sei in una situazione di obesità di classe 1 e ciò comporta grossi rischi per la tua salute. Segui attentamente la dieta e riusciremo insieme a tornare in forma! Posso aiutarti in qualcos altro?';
  }
  if (Imc >= 35.00 && Imc <= 39.00) {
       speakOutput= 'L\u0027 indice di massa corporea (abbreviato IMC o BMI, dall\u0027 inglese body mass index) è un dato biomètrico, espresso come rapporto tra peso e quadrato dell\u0027 altezza di un individuo ed è utilizzato come un indicatore dello stato di peso forma. Il tuo IMC è di '+Imc+', sei in una situazione di obesità di classe 2 e ciò comporta grossi rischi per la tua salute. Segui attentamente la dieta e riusciremo insieme a tornare in forma! Posso aiutarti in qualcos altro?';
  }
  if (Imc >= 40.00) {
       speakOutput= 'L\u0027 indice di massa corporea (abbreviato IMC o BMI, dall\u0027 inglese body mass index) è un dato biomètrico, espresso come rapporto tra peso e quadrato dell\u0027 altezza di un individuo ed è utilizzato come un indicatore dello stato di peso forma. Il tuo IMC è di '+Imc+', sei in una situazione di obesità di classe 3 e ciò comporta grossi rischi per la tua salute. Segui attentamente la dieta e riusciremo insieme a tornare in forma! Posso aiutarti in qualcos altro?';
  }

   const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
              .speak(speakOutput)
              .reprompt(speakOutput)
              .getResponse();
      
      }
      
  };

  const NotAStatementIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === ' NotAStatementIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Scusami, non ho capito, potresti ripetere?';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
              .speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  const SostPastaIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'SostPastaIntent';
      },
      handle(handlerInput) {
          var speakOutput ="ok";
         
             speakOutput = 'Ok, ti accontento! Al posto della pasta potresti mangiare nelle stesse quantità riso, quinoa o avena. Spero di averti accontentato, se hai bisogno di sostituire altro chiedi pure.';
           
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
              .speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };
  const NoIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'NoIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Ok, come vuoi.';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };
  
  const allenamentoIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'allenamentoIntent';
      },
      handle(handlerInput) {
          
          const speakOutput = 'Benvenuto nel programma di allenamento. Questo programma dura 7 minuti e prevede l\u0027esecuzione di 10 diversi esercizi a corpo libero. Se sei pronto, dimmi "iniziamo"';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };
  
   const iniziamoIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'iniziamoIntent';
      },
       handle(handlerInput) {
      let speakOutput = 'Okay, iniziamo con del riscaldamento: il primo esercizio è la corsa sul posto. Per passare al prossimo, dimmi "prossimo esercizio". Tre, due, uno... via!';

           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  const GrazieIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'GrazieIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Quando vuoi sono qui!';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };


  const SostTonnoInScatolaIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'SostTonnoInScatolaIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Il tonno in scatola può essere sostituito nelle stesse quantità con salmone, spigola o sgombro.';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  const SostZucchineIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'SostZucchineIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Le verdure possono essere sostituite tra loro senza alcuna limitazione.';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };


  const AiutoASeguireUnaDietaIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AiutoASeguireUnaDietaIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Se vuoi una mano a seguire la tua dieta stai parlando con il bot giusto! Puoi chiedermi: cosa prevede la dieta oggi, cosa mangerai nei prossimi giorni o in tutta la settimana.';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  const SostbarBabietoleIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'SostbarBabietoleIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Le verdure possono essere sostituite tra loro senza alcuna limitazione.';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };



  const SostTacchinoIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'SostTacchinoIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Ok vedo di accontentarti, al posto del tacchino potresti mangiare nelle stesse quantità pollo o vitello. Spero ci sia una alternativa di tuo gradimento, nel caso volessi fare altre sostituzioni non esitare a chiedere!';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };
  const numeroIntenHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'numeroIntent';
      },
       handle(handlerInput) {
           
      if(typeof autCode === 'undefined'|| autCode === 0){
          const speakOutput = 'Mi dispiace, ma non conosco il numero del tuo nutrizionista perchè non ha registrato la tua dieta sul portale.';
          return handlerInput.responseBuilder
        .speak(speakOutput)
        .reprompt(' ')
        .getResponse();
      }else{
          return dialogflowAgentDoc.get()
              .then(doc => {
               let e = doc.data().email;
               const dialogflowAgentDott = db.collection('users').doc(e)
       return dialogflowAgentDott.get()
              .then(doc => {
          let nome = doc.data().cognome;
           let telefono = doc.data().telefono;
           var res = telefono.split("");
          const speakOutput = 'Il numero del Dottor ' + nome + ' è ' + res[0]+' ' + res[1]+' ' +res[2]+' ' +res[3]+' ' +res[4]+' ' +res[5]+' ' +res[6]+' ' +res[7]+' ' +res[8]+' ' +res[9]+'.';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
              })});}}
  };
  const VenIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'VenIntent';
      },
       handle(handlerInput) {
           
      if(typeof autCode === 'undefined'|| autCode === 0){
          const speakOutput = 'Mi dispiace ma non so cosa mangerai venerdì perchè non sei ancora in possesso di una dieta. Contatta il tuo nutrizionista per ottenerla!';
          return handlerInput.responseBuilder
        .speak(speakOutput)
        .reprompt(' ')
        .getResponse();
      }else{
          return dialogflowAgentDoc.get()
              .then(doc => {
      const speakOutput = 'La tua dieta il venerdì prevede\n\nColazione:\n' + doc.data().colazione_del_venerdì + '\n\nPranzo:\n' + doc.data().pranzo_del_venerdì + '\n\nCena:\n' + doc.data().cena_del_venerdì;

   const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(speakOutput)
              .getResponse();
       });}}
  };

  const SostPolloIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'SostPolloIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Ok vedo di accontentarti, al posto del pollo potresti mangiare nelle stesse quantità tacchino o vitello. Spero ci sia una alternativa di tuo gradimento, nel caso volessi fare altre sostituzioni non esitare a chiedere!';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  const HoFameIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'HoFameIntent';
      },
      handle(handlerInput) {
          if(typeof autCode === 'undefined'|| autCode === 0){
          const speakOutput = 'Ecco alcune proposte di snack light e gustosi che calmano la fame: mandorle, frutta, yogurt greco, bresaola, fesa di tacchino, uova sode e bane integrale.';
          return handlerInput.responseBuilder
        .speak(speakOutput)
        .reprompt(' ')
        .getResponse();
      }else{
          return dialogflowAgentDoc.get()
              .then(doc => {
      const speakOutput= 'La tua dieta prevede durante la mattinata uno spuntino consistente in: ' + doc.data().spuntino+ ' Nel pomeriggio potresti fare merenda con: ' + doc.data().merenda;

   const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(speakOutput)
              .getResponse();
       });}}
  };

  const SostLatteIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'SostLatteIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Ok cerchiamo insieme una alternativa, al posto del latte potresti mangiare yogurt magro. Spero che l\u0027 alternativa fornita sia di tuo gradimento, se hai altre sostituzioni da fare non esitare a chiedere!';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  const SostMerluzzoIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'SostMerluzzoIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Puoi sostituire il merluzzo rispettando le stesse dosi con la sogliola';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };
  const SalutoIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'SalutoIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Ciao, spero che tu stia bene. Come posso aiutarti?';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };
  
  
  const prossimoesercizioIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'prossimoesercizioIntent';
      },
      handle(handlerInput) {
          var rand = Math.floor(Math.random() * 12);
          var speakOutput ="Okay, prossimo esercizio: "; 
          switch (rand) {
              case 0:
                   speakOutput = speakOutput+ 'push up';
              break;
              case 1:
                  speakOutput = speakOutput+ 'jumping jack';
              break;
              case 2:
                  speakOutput = speakOutput+ 'corsa sul posto';
                  break;
               case 3:
                   speakOutput = speakOutput+ 'plank';
                   break;
               case 4:
                   speakOutput = speakOutput+ 'plank laterale';
                   break;
                   case 5:
                   speakOutput = speakOutput+ 'crunch inverso';
                   break;
                   case 6:
                   speakOutput = speakOutput+ 'affondi laterali';
                   break;
                   case 7:
                   speakOutput = speakOutput+ 'affondi in avanti';
                   break;
                   case 8:
                   speakOutput = speakOutput+ 'addominali';
                   break;
                   case 9:
                  speakOutput = speakOutput+ 'squat';
                  break;
                  case 10:
                  speakOutput = speakOutput+ 'flessioni';
                  break;
                  case 11:
                  speakOutput = speakOutput+ 'burpees';
                  break;
          }
          speakOutput = speakOutput+ '. Per passare al successivo, dimmi "prossimo esercizio". Tre, due, uno... via!';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };
  
  

  const ScoraggiamentoIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'ScoraggiamentoIntent';
      },
      handle(handlerInput) {
          var rand = Math.floor(Math.random() * 5);
          var speakOutput =""; 
          switch (rand) {
              case 0:
                   speakOutput = 'La lotta che stai vivendo oggi genera la forza di cui avrai bisogno domani';
              break;
              case 1:
                  speakOutput = 'Sii la versione migliore di te stesso.';
              break;
              case 2:
                  speakOutput = 'Non è una dieta, è un cambiamento di stile di vita.';
              break;
               case 3:
                   speakOutput = 'Lotta per progredire, non per essere perfetto.';
              break;
               case 4:
                   speakOutput = 'Il successo è la somma di tanti piccoli sforzi, ottenuti giorno dopo giorno.';
              break;
                          
          }
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  const CosaMangioDomaniIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'CosaMangioDomaniIntent';
      },
      handle(handlerInput) {
          if(typeof autCode === 'undefined' || autCode ===0){
          const speakOutput = 'Mi dispiace ma non so cosa mangerai domani perchè non sei ancora in possesso di una dieta. Contatta il tuo nutrizionista per ottenerla!';
          return handlerInput.responseBuilder
        .speak(speakOutput)
        .reprompt(' ')
        .getResponse();
      }else{
          
         return dialogflowAgentDoc.get()
              .then(doc => {
      var d = new Date();
      var weekday = new Array(7);
      weekday[0] =  'Sunday';
      weekday[1] = 'Monday';
      weekday[2] = 'Tuesday';
      weekday[3] = 'Wednesday';
      weekday[4] = 'Thursday';
      weekday[5] = 'Friday';
      weekday[6] = 'Saturday';
      
      var n = weekday[d.getDay()];
      var speakOutput = "che giorno è oggi?";
      if (n === 'Monday') {
           
         speakOutput = 'La tua dieta il martedì prevede\n\nColazione:\n' + doc.data().colazione_del_martedì + '\n\nPranzo:\n' + doc.data().pranzo_del_martedì + '\n\nCena:\n' + doc.data().cena_del_martedì;
          }
      if (n === 'Tuesday') {
           
         speakOutput = 'La tua dieta il mercoledì prevede\n\nColazione:\n' + doc.data().colazione_del_mercoledì + '\n\nPranzo:\n' + doc.data().pranzo_del_mercoledì + '\n\nCena:\n' + doc.data().cena_del_mercoledì;
          }
      if (n === 'Wednesday') {
           
         speakOutput = 'La tua dieta il giovedì prevede\n\nColazione:\n' + doc.data().colazione_del_giovedì + '\n\nPranzo:\n' + doc.data().pranzo_del_giovedì + '\n\nCena:\n' + doc.data().cena_del_giovedì;
           }
      if (n === 'Thursday') {
           
         speakOutput = 'La tua dieta il venerdì prevede\n\nColazione:\n' + doc.data().colazione_del_venerdì + '\n\nPranzo:\n' + doc.data().pranzo_del_venerdì + '\n\nCena:\n' + doc.data().cena_del_venerdì;
           }
      if (n === 'Friday') {
         speakOutput = 'La tua dieta il sabato prevede\n\nColazione:\n' + doc.data().colazione_del_sabato + '\n\nPranzo:\n' + doc.data().pranzo_del_sabato + '\n\nCena:\n' + doc.data().cena_del_sabato;
           }
      if (n === 'Saturday') {
          speakOutput = 'La tua dieta la domenica prevede\n\nColazione:\n' + doc.data().colazione_della_domenica + '\n\nPranzo:\n' + doc.data().pranzo_della_domenica + '\n\nCena:\n' + doc.data().cena_della_domenica;
           }
      if (n === 'Sunday') {
          speakOutput = 'La tua dieta il lunedì prevede\n\nColazione:\n' + doc.data().colazione_del_lunedì + '\n\nPranzo:\n' + doc.data().pranzo_del_lunedì + '\n\nCena:\n' + doc.data().cena_del_lunedì;

         }
      
   const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(speakOutput)
              .getResponse();
       });}}
  };


  const MiSpiegherestiCosaYourDietIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'MiSpiegherestiCosaYourDietIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Your Diet è un sito web all\u0027 interno del quale nutrizionisti convenzionati possono inserire le diete dei loro pazienti. Una volta inserita una dieta all\u0027 interno del portale, io posso accedervi e quindi aiutare i pazienti a seguirla.';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  const MarIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'MarIntent';
      },
      handle(handlerInput) {
          if(typeof autCode === 'undefined'|| autCode === 0){
          const speakOutput = 'Mi dispiace ma non so cosa mangerai martedì perchè non sei ancora in possesso di una dieta. Contatta il tuo nutrizionista per ottenerla!';
          return handlerInput.responseBuilder
        .speak(speakOutput)
        .reprompt(' ')
        .getResponse();
      }else{
           return dialogflowAgentDoc.get()
              .then(doc => {
          const speakOutput = 'La tua dieta il martedì prevede\n\nColazione:\n' + doc.data().colazione_del_martedì + '\n\nPranzo:\n' + doc.data().pranzo_del_martedì + '\n\nCena:\n' + doc.data().cena_del_martedì;
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(speakOutput)
              .getResponse();
       });}}
  };

  const ConsigliIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'ConsigliIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Posso consigliare degli alimenti per: soggetti carenti di ferro, soggetti intolleranti al lattosios soggetti intolleranti al glutine, soggetti aventi il colesterolo alto, soggetti che soffrono l\u0027 acne, rilassarti, sconfiggere la sonnolenza, alimenti contro i gas intestinali, alimenti contro il gonfiore addominale';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  const SostProsciuttoCrudoIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'SostProsciuttoCrudoIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Se non ti va il prosciutto crudo posso proporti nelle stesse quantità: fesa di tacchino o bresaola. Spero ci sia una alternativa di tuo gradimento, se hai altro da sostituire non esitare a chiedere';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  const SostOrzoIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'SostOrzoIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Ok come alternative all\u0027 orzo puoi mangiare nelle stesse quantità: pasta di grano duro o riso. Spero che ci sia una alternativa di tuo gradimento, nel caso volessi fare altre sostituzioni non esitare a chiedere!';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  const TuttaLaDietaIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'TuttaLaDietaIntent';
      },
      handle(handlerInput) {
          if(typeof autCode === 'undefined'|| autCode === 0){
          const speakOutput = 'Mi dispiace ma non so cosa mangerai questa settimana perchè non sei ancora in possesso di una dieta. Contatta il tuo nutrizionista per ottenerla!';
          return handlerInput.responseBuilder
        .speak(speakOutput)
        .reprompt(' ')
        .getResponse();
      }else{
          return dialogflowAgentDoc.get()
              .then(doc => {
      const speakOutput= 'La tua dieta il lunedì prevede\n\nColazione:\n' + doc.data().colazione_del_lunedì + '\n\nPranzo:\n' + doc.data().pranzo_del_lunedì + '\n\nCena:\n' + doc.data().cena_del_lunedì + 'La tua dieta il Martedì prevede\n\nColazione:\n' + doc.data().colazione_del_martedì + '\n\nPranzo:\n' + doc.data().pranzo_del_martedì + '\n\nCena:\n' + doc.data().cena_del_martedì+ 'La tua dieta il Mercoledì prevede\n\nColazione:\n' + doc.data().colazione_del_mercoledì + '\n\nPranzo:\n' + doc.data().pranzo_del_mercoledì + '\n\nCena:\n' + doc.data().cena_del_mercoledì+ 'La tua dieta il Giovedì prevede\n\nColazione:\n' + doc.data().colazione_del_giovedì + '\n\nPranzo:\n' + doc.data().pranzo_del_giovedì + '\n\nCena:\n' + doc.data().cena_del_giovedì+ 'La tua dieta il Venerdì prevede\n\nColazione:\n' + doc.data().colazione_del_venerdì + '\n\nPranzo:\n' + doc.data().pranzo_del_venerdì + '\n\nCena:\n' + doc.data().cena_del_venerdì+ 'La tua dieta il Sabato prevede\n\nColazione:\n' + doc.data().colazione_del_sabato + '\n\nPranzo:\n' + doc.data().pranzo_del_sabato + '\n\nCena:\n' + doc.data().cena_del_sabato+ 'La tua dieta la Domenica prevede\n\nColazione:\n' + doc.data().colazione_della_domenica + '\n\nPranzo:\n' + doc.data().pranzo_della_domenica + '\n\nCena:\n' + doc.data().cena_della_domenica;

   const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(speakOutput)
              .getResponse();
       });}}
  };

  const InfoSostituzioniIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'InfoSostituzioniIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Effettuare una sostituzione è semplicissimo basta chiedermi ad esempio con cosa posso sostituire il pollo?. Di seguito troverai la lista degli alimenti per cui so indicarti una alternativa 🙂: -Pollo - Tacchino - Vitello magro - Bresaola - Fesa di tacchino - Tonno in scatola - Merluzzo - Sogliola - Gamberi - Lenticchie - Fagioli - Fave - Zucchine - Barbabietole - Latte - Yogurt - Pasta - Riso - Fette biscottate - Prosciutto crudo magro - Orzo';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  const DomIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'DomIntent';
      },
      handle(handlerInput) {
          if(typeof autCode === 'undefined'|| autCode === 0){
          const speakOutput = 'Mi dispiace ma non so cosa mangerai domenica perchè non sei ancora in possesso di una dieta. Contatta il tuo nutrizionista per ottenerla!';
          return handlerInput.responseBuilder
        .speak(speakOutput)
        .reprompt(' ')
        .getResponse();
      }else{
          return dialogflowAgentDoc.get()
              .then(doc => {
      const speakOutput = 'La tua dieta la domenica prevede\n\nColazione:\n' + doc.data().colazione_della_domenica + '\n\nPranzo:\n' + doc.data().pranzo_della_domenica + '\n\nCena:\n' + doc.data().cena_della_domenica;

   const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(speakOutput)
              .getResponse();
       });}}
  };


  const SostLenticchieIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'SostLenticchieIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Ok vediamo di accontentarti, al posto delle lenticchie potresti mangiare nelle stesse quantità: fagioli o fave. Spero che ci sia una alternativa di tuo gradimento, se hai bisogno di fare altre sostituzioni non esitare a chiedere!';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  const SostYogurtIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'SostYogurtIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Ok, al posto dello yogurt potresti assumere nelle stesse quantità latte. Spero che l\u0027 alternativa proposta sia di tuo gradimento, nel caso volessi effettuare altre sostituzioni sono a tua disposizione!';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  const AlimentiGasintestinaliIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AlimentiGasintestinaliIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'I rimedi alimentari spesso possono essere molto utili per eliminare, correggere, ridurre la flatulenza. Tra gli alimenti consigliati dagli esperti ci sono il finocchio (che favorisce l’espulsione dei gas), le mele, i mirtilli e la menta ottimi per regolare la fermentazione intestinale. Tuttavia per tale fenomeno vi sono vari rimedi, naturali e non. Si consiglia, nel caso in cui il problema si ripresenta sistematicamente, l’uso di una dieta apposita, su consiglio di un esperto. Se il tuo problema persiste allora ti consiglio di contattare un esperto Per altre informazioni io resto sempre a tua disposizione!';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  const ConsiglioNoGlutineIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'ConsiglioNoGlutineIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'L’alimentazione senza glutine non è, come potrebbe sembrare, punitiva, limitativa o legata necessariamente al concetto di rinuncia. Partiamo dall’alimentazione mediterranea, alla quale gli italiani fanno riferimento: scopriremo una moltitudine di alimenti naturalmente privi di glutine che ognuno di noi consuma giornalmente, sia egli celiaco o meno, e che sono alla base di numerose ricette, dalle più semplici alle più elaborate. Tra questi alimenti vi sono: riso, mais, grano saraceno, legumi, patate, pesce, carne, uova, latte e formaggi, ortaggi e frutta. Il celiaco dispone dunque di tutti i componenti per costruire una dieta bilanciata e varia, con una particolare attenzione da prestare nella scelta delle fonti di carboidrati che devono sostituire i cereali vietati. Scelta che non deve ricadere esclusivamente sulla vastissima gamma di prodotti sositutivi senza glutine disponibili sul mercato, ma anche sui cereali naturalmente senza glutine come riso e mais o altre fonti di carboidrati come le patate.';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  const LunIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'LunIntent';
      },
      handle(handlerInput) {
          if(typeof autCode === 'undefined'|| autCode === 0){
          const speakOutput = 'Mi dispiace ma non so cosa mangerai lunedì perchè non sei ancora in possesso di una dieta. Contatta il tuo nutrizionista per ottenerla!';
          return handlerInput.responseBuilder
        .speak(speakOutput)
        .reprompt(' ')
        .getResponse();
      }else{
          return dialogflowAgentDoc.get()
              .then(doc => {

          const speakOutput = 'La tua dieta il lunedì prevede\n\nColazione:\n' + doc.data().colazione_del_lunedì + '\n\nPranzo:\n' + doc.data().pranzo_del_lunedì + '\n\nCena:\n' + doc.data().cena_del_lunedì;
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(speakOutput)
              .getResponse();
       });}}
  };

  const MangiatoOggiIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'MangiatoOggiIntent';
      },
      handle(handlerInput) {
          if(typeof autCode === 'undefined'|| autCode === 0){
          const speakOutput = 'Mi dispiace ma non so cosa mangerai oggi perchè non sei ancora in possesso di una dieta. Contatta il tuo nutrizionista per ottenerla!';
          return handlerInput.responseBuilder
        .speak(speakOutput)
        .reprompt(' ')
        .getResponse();
      }else{
          
         return dialogflowAgentDoc.get()
              .then(doc => {
      var d = new Date();
      var weekday = new Array(7);
      weekday[0] =  'Sunday';
      weekday[1] = 'Monday';
      weekday[2] = 'Tuesday';
      weekday[3] = 'Wednesday';
      weekday[4] = 'Thursday';
      weekday[5] = 'Friday';
      weekday[6] = 'Saturday';
      
      var n = weekday[d.getDay()];
      var speakOutput = "che giorno è oggi?";
      if (n === 'Monday') {
      speakOutput = 'La tua dieta il Lunedì prevede\n\nColazione:\n' + doc.data().colazione_del_lunedì + '\n\nPranzo:\n' + doc.data().pranzo_del_lunedì + '\n\nCena:\n' + doc.data().cena_del_lunedì;
      }
      if (n === 'Tuesday') {
         speakOutput = 'La tua dieta il Martedì prevede\n\nColazione:\n' + doc.data().colazione_del_martedì + '\n\nPranzo:\n' + doc.data().pranzo_del_martedì + '\n\nCena:\n' + doc.data().cena_del_martedì;
      }
      if (n === 'Wednesday') {
         speakOutput = 'La tua dieta il Mercoledì prevede\n\nColazione:\n' + doc.data().colazione_del_mercoledì + '\n\nPranzo:\n' + doc.data().pranzo_del_mercoledì + '\n\nCena:\n' + doc.data().cena_del_mercoledì;
            }
      if (n === 'Thursday') {
         speakOutput = 'La tua dieta il Giovedì prevede\n\nColazione:\n' + doc.data().colazione_del_giovedì + '\n\nPranzo:\n' + doc.data().pranzo_del_giovedì + '\n\nCena:\n' + doc.data().cena_del_giovedì;
            }
      if (n === 'Friday') {
         speakOutput = 'La tua dieta il Venerdì prevede\n\nColazione:\n' + doc.data().colazione_del_venerdì + '\n\nPranzo:\n' + doc.data().pranzo_del_venerdì + '\n\nCena:\n' + doc.data().cena_del_venerdì;
            }
      if (n === 'Saturday') {
         speakOutput = 'La tua dieta il Sabato prevede\n\nColazione:\n' + doc.data().colazione_del_sabato + '\n\nPranzo:\n' + doc.data().pranzo_del_sabato + '\n\nCena:\n' + doc.data().cena_del_sabato;
            }
      if (n === 'Sunday') {
         speakOutput = 'La tua dieta la Domenica prevede\n\nColazione:\n' + doc.data().colazione_della_domenica + '\n\nPranzo:\n' + doc.data().pranzo_della_domenica + '\n\nCena:\n' + doc.data().cena_della_domenica;
            }
      
   const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(speakOutput)
              .getResponse();
       });}}
  };

  const ColesteroloConsigliIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'ColesteroloConsigliIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Per il colesterolo sono consigliati i seguenti alimenti: Fibre solubili: buone fonti di fibra solubile includono crusca d avena, orzo, noci, semi, fagioli, mele, pere, prugne, lenticchie e piselli. Pollame (senza pelle) e carni magre Pesci grassi: salmone ,trota, tonno, sgombro';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  const GonfioreAddomeIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'GonfioreAddomeIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'il gonfiore è un problema che si concentra sul tronco. Bisogna lavorare sull\u0027 abbinamento degli alimenti in modo da trovare la combinazione giusta alla propria digestione!';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  const CosaSaiFareIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'CosaSaiFareIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Ti ripeto subito quali sono le mie funzioni: Posso aiutarti a seguire la tua dieta personale inserita dal tuo nutrizionista all\u0027 interno del portale , posso fornirti delle alternative per alimenti non desiderati all\u0027 interno della dieta , Posso darti consigli sugli alimenti da assumere in presenza di alcune patologie e di alcuni disturbi , Posso aggiornare il tuo peso e fornirti una analisi della tua situazione calcolando il tuo IMC(indice di massa corporea)';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  const SostFesaTacchinoIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'SostFesaTacchino';
      },
      handle(handlerInput) {
          const speakOutput = 'Se la fesa di tacchino non è di tuo gradimento, potresti mangiare nelle stesse quantità della bresaola. Spero sia di tuo gradimento, nel caso volessi effettuare altre sostituzioni non esitare a chiedere!';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  const SostBresaolaIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'SostBresaolaIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Se la bresaola non è di tuo gradimento, potresti mangiare nelle stesse quantità della fesa di tacchino. Spero sia di tuo gradimento, nel caso volessi effettuare altre sostituzioni non esitare a chiedere!';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };
  const GioIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'GioIntent';
      },
      handle(handlerInput) {
          if(typeof autCode === 'undefined'|| autCode === 0){
          const speakOutput = 'Mi dispiace ma non so cosa mangerai giovedì perchè non sei ancora in possesso di una dieta. Contatta il tuo nutrizionista per ottenerla!';
          return handlerInput.responseBuilder
        .speak(speakOutput)
        .reprompt(' ')
        .getResponse();
      }else{
          return dialogflowAgentDoc.get()
              .then(doc => {
      const speakOutput = 'La tua dieta il giovedì prevede\n\nColazione:\n' + doc.data().colazione_del_giovedì + '\n\nPranzo:\n' + doc.data().pranzo_del_giovedì + '\n\nCena:\n' + doc.data().cena_del_giovedì;

   const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(speakOutput)
              .getResponse();
       });}}
  };

  const SostFetteBiscottateIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'SostFetteBiscottateIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Potresti sostituire le fette biscottate con: pane o biscotti secchi. Spero ci sia una alternativa di tuo gradimento, se hai altre sostituzioni da effettuare non esitare a chiedere!';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };
  const NonHoUnaDietaIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'NonHoUnaDietaIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Non preoccuparti, aspetto che tu ne abbia una! Ti ricordo che posso accedere soltanto a diete personali inserite da nutrizionisti all\u0027 interno del portale.';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  const allattamentoIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'allattamentoIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'In allattamento le tue necessità nutritive sono perfino superiori a quelle della gravidanza: un’alimentazione variata, ricca di acqua, vegetali freschi, pesce, latte e derivati, ti aiuterà a star bene e a produrre un latte del tutto adatto alle esigenze del neonato. Evita quegli alimenti che possono conferire odori o sapori sgraditi al tuo latte o scatenare nel lattante manifestazioni di tipo allergico. Evita le bevande alcoliche e usa i prodotti contenenti sostanze nervine (caffè, tè, cacao, bevande a base di cola) con cautela.';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };
  const SostGamberiIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'SostGamberiIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Cerchiamo insieme una alternativa, al posto dei gamberi potresti mangiare nelle stesse quantità: polpo di scoglio o sgombro. Spero ci sia una alternativa di tuo gradimento, se hai altre sostituzioni da effettuare non esitare a chiedere!';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  const SostVitelloIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'SostVitelloIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Al posto del vitello potresti mangiare nella stessa quantità coniglio, pollo o tacchino';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  const AlimentoAntisonnolenzaIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AlimentoAntisonnolenzaIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Oltre al classico caffè, alcuni alimenti per allontanare la sonnolenza sono : qualche pezzo di cioccolato amaro o di frutta secca.';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  const KappaIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'KappaIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Ok, ricorda che io rimango qui a tua disposizione';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };


  const MerIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'MerIntent';
      },
      handle(handlerInput) {
          if(typeof autCode === 'undefined'|| autCode === 0){
          const speakOutput = 'Mi dispiace ma non so cosa mangerai mercoledì perchè non sei ancora in possesso di una dieta. Contatta il tuo nutrizionista per ottenerla!';
          return handlerInput.responseBuilder
        .speak(speakOutput)
        .reprompt(' ')
        .getResponse();
      }else{
          return dialogflowAgentDoc.get()
              .then(doc => {
      const speakOutput = 'La tua dieta il mercoledì prevede\n\nColazione:\n' + doc.data().colazione_del_mercoledì + '\n\nPranzo:\n' + doc.data().pranzo_del_mercoledì + '\n\nCena:\n' + doc.data().cena_del_mercoledì;

   const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(speakOutput)
              .getResponse();
       });}}
  };

          
          const seiliIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'seiliIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Eccomi qui. Come posso aiutarti?';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };      
          const seifeliceIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'seifeliceIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Sono sempre di buon umore.';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };   
          
          const seidivertenteIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'seidivertenteIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Mi piace far sorridere le persone.';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };   
          
            const seiunbotIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'seiunbotIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'No, sono un Fit Bot!';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };   
         
         const seiimpegnatoIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'seiimpegnatoIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Sono sempre libero per te.';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };   
         
        const chieiltuobossIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'chieiltuobossIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Sono stato programmato da Francesca e Domenico!';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };  
          
       const seibellissimoIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'seibellissimoIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Così mi fai arrossire!';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  }; 

       const seiirritanteIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'seiirritanteIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Scusami, cercherò di essere più garbato.';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };     
      
      const quantiannihaiIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'quantiannihaiIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'è un segreto... mi mantengo giovane mangiando sano!';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };  
          
      const chiseiIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'chiseiIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Sono Fit Bot, il tuo assistente fit personale!';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };    
          
          

  const SostFagioliIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'SostFagioliIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Se non hai voglia dei fagioli, potresti mangiare nelle stesse quantità: lenticchie o fave. Spero di averti accontentato, nel caso volessi effettuare altre sostituzioni non esitare a chiedere!';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  const SostFaveIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'SostFaveIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Se non hai voglia di fave, potresti mangiare nelle stesse quantità: lenticchie o fagioli. Spero di averti accontentato, nel caso volessi effettuare altre sostituzioni non esitare a chiedere!';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  const SostSogliolaIntent = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'SostSogliolaIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Al posto della sogliola potresti mangiare nelle stesse quantità: merluzzo o rombo. Spero ci sia una alternativa di tuo gradimento, nel caso volessi effettuare altre sostituzioni non esitare a chiedere!';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  const AlimentiAcneIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AlimentiAcneIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Se hai problemi di acne, preferire alimenti vegetali come frutta e verdura (vitamina C ed E) . Assumere inoltre un adeguato quantitativo di carboidrati raffinati, vitamine, sali minerali, glucidi complessi, fibre, proteine e grassi è un importante rimedio per prevenire l\u0027 acne o per attenuarne i sintomi . Va bene anche assumere fermenti lattici vivi :costituisce un buon rimedio per combattere l\u0027 acne dall\u0027 interno.';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  const cosamangiareIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'cosamangiareIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Per stare in forma, consuma più cereali, legumi, verdura e frutta, scegli grassi di qualità e limitane la quantità, controlla il peso e mantieniti sempre attivo, limita zuccheri, dolci e bevande zuccherate, varia spesso le tue scelte a tavola, consuma bevande alcoliche in quantità limitata, non eccedere col sale ma soprattutto bevi ogni giorno acqua in abbondanza!';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  const ConsiglioFerroBassoIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'ConsiglioFerroBassoIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'La prevenzione è molto importante per evitare l’anemia sideropenica. Bisogna seguire un’alimentazione varia, che includa alimenti ricchi di ferro come carne rossa, carne di maiale, verdure a foglia verde, frutta secca, pollo, frutti di mare, fagioli. A questi alimenti si possono affiancare cibi con alto contenuto di vitamina C che migliorano l’assorbimento di ferro. Altri alimenti indicati sono il cioccolato fondente,ceci, radicchio, pistacchio, lenticchie, rucola, spinaci.';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };
  const comestaiIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'comestaiIntent';
      },
      handle(handlerInput) {
          var speakOutput = 'ok';
          if(typeof autCode === 'undefined' || autCode ===0){
              speakOutput = 'Tutto bene, grazie!';
          }else{
              speakOutput = 'Tutto bene, grazie. Come procede la dieta?';
              
          }
           
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };
  const beneIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'beneIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Mi fa piacere saperlo! Se hai bisogno di qualche informazione sono a tua completa disposizione.';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };
  const maleIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'maleIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Mi dispiace sentirlo. Se vuoi, posso aiutarti a sostituire degli alimenti che non ti piacciono.';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };
  const SabIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'SabIntent';
      },
      handle(handlerInput) {
          if(typeof autCode === 'undefined'|| autCode === 0){
          const speakOutput = 'Mi dispiace ma non so cosa mangerai sabato perchè non sei ancora in possesso di una dieta. Contatta il tuo nutrizionista per ottenerla!';
          return handlerInput.responseBuilder
        .speak(speakOutput)
        .reprompt(' ')
        .getResponse();
      }else{
          return dialogflowAgentDoc.get()
              .then(doc => {
      const speakOutput = 'La tua dieta il sabato prevede\n\nColazione:\n' + doc.data().colazione_del_sabato + '\n\nPranzo:\n' + doc.data().pranzo_del_sabato + '\n\nCena:\n' + doc.data().cena_del_sabato;

   const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(speakOutput)
              .getResponse();
       });}}
  };

  const SostRisoIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'SostRisoIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Ok ti propongo delle alternative, puoi mangiare nelle stesse quantità: pasta di grano duro, quinoa o orzo. Spero di averti accontentato, se hai bisogno di sostituire altro chiedi pure.';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  const LiquidiInfoIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'LiquidiInfoIntent';
      },
      handle(handlerInput) {
          const altezza = Alexa.getSlotValue(handlerInput.requestEnvelope,'altezza');
          const peso = Alexa.getSlotValue(handlerInput.requestEnvelope,'peso');
          const acqua = (parseInt(peso) + parseInt(altezza))/100;
          const bicchieri = parseInt(acqua/0.25);
          const speakOutput = 'Indicativamente, dovresti bere '+acqua+' litri d\u0027acqua al giorno, che equivalgono a circa '+bicchieri+ ' bicchieri.';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };


  const gravidanzaIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'gravidanzaIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Se sei in dolce attesa, evita aumenti eccessivi di peso e fai attenzione a coprire i tuoi aumentati fabbisogni in proteine, calcio, ferro, folati e acqua: consuma quindi abitualmente pesce, carni magre, uova, latte e derivati e un’ampia varietà di verdura e frutta. In particolare, durante tutta l’età fertile abbi cura che la tua assunzione di folati copra i tuoi bisogni. In questo modo ridurrai il rischio di alterazioni del tubo neurale (spina bifida) nel feto. Non consumare cibi di origine animale crudi o poco cotti e non assumere bevande alcoliche.';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  const ConsiglioNoLattosioIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'ConsiglioNoLattosioIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Le concentrazioni maggiori di lattosio si registrano nel latte, nello yogurt e nei latti fermentati, nei gelati, nei formaggi molli e nel burro. Gli individui fortemente intolleranti al lattosio devono prestare particolare attenzione anche alle fonti alimentari per così dire "nascoste". Questo zucchero viene infatti addizionato come eccipiente a farmaci ed integratori vari, e si ritrova - seppur in piccole quantità - in diversi prodotti alimentari(tra cui margarina, pane e altri prodotti da forno,carne e salumi).';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  const AlimentoRelaxIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AlimentoRelaxIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Per favorire il sonno ci sono diversi alimenti. Principalmente le tisane sono un ottimo alimento che aiuta a ridurre l\u0027 insonnolenza.';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };
  const anzianiIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'anzianiIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Sforzati di consumare sistematicamente una dieta variata e appetibile. Evita il ricorso troppo frequente a pasti freddi, piatti precucinati o riscaldati. Scegli gli alimenti sulla base delle condizioni del tuo apparato masticatorio e preparali in modo adeguato: tritare le carni, grattugiare o schiacciare frutta ben matura, preparare minestre, purea e frullati, scegliere un pane morbido o ammorbidirlo in un liquido. Evita pasti pesanti e fraziona l’alimentazione in più occasioni nell’arco della giornata. Fai una buona prima colazione comprendente anche latte o yogurt. Conserva un peso corporeo accettabile, continuando a mantenere un buon livello di attività motoria ed evitando di abusare di condimenti grassi e di dolci. Riduci i grassi animali, scegli frequentemente il pesce e le carni alternative (pollo, tacchino, coniglio), non esagerare con i formaggi. Consuma spesso legumi, frutta e verdura freschi. Non eccedere con il consumo di bevande alcoliche e con l’aggiunta del sale da cucina.';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };const bambiniIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'bambiniIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Consuma la prima colazione, suddividi opportunamente la tua alimentazione nel corso della giornata e scegli più frequentemente verdura e frutta. Evita di eccedere nel consumo di alimenti dolci e di bevande gassate, e di concederti con troppa frequenza i piatti tipici del fast-food all’americana. Dedica almeno 1 ora al giorno all’attività fisica e al movimento.';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };
  const menopausaIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'menopausaIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Sfrutta l’eventuale aumentata disponibilità di tempo libero per praticare una maggiore attività motoria e per curare la tua alimentazione: impara a non squilibrare mai la dieta e ricordati che, dato che ogni cibo ha un suo preciso ruolo nel contesto dell’alimentazione quotidiana, non devi mai eliminare indiscriminatamente interi gruppi di alimenti a favore di altri. Non esagerare con latte e formaggi, nonostante il loro cospicuo contenuto in calcio; preferisci il latte parzialmente scremato e, tra i formaggi, scegli quelli a minor contenuto in grassi e di sale. Consuma tutti i giorni e in abbondanza frutta fresca e verdura. Usa preferibilmente l’olio d’oliva extravergine. Ricordati che anche in menopausa il sovrappeso e l’obesità, la sedentarietà, la stitichezza, il fumo di sigaretta e l’abuso dell’alcol rappresentano importanti fattori di rischio.';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  const InsonniaIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'InsonniaIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Vi sono degli alimenti che sono di aiuto per combattere l’insonnia. Gli alimenti che contengono il triptofano sono quelli da privilegiare. Il latte e lo yogurt sono ottimi alleati, come anche uova, cioccolato, semi e frutta secca a guscio. È possibile potenziare l’effetto di questi cibi aiutandosi con la preparazione di tisane dalle proprietà rilassanti e distensive. Le erbe consigliate sono: la melissa, il tiglio, la passiflora, il biancospino,la camomilla, i fiori di arancio, la verbena.';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

const hofinitoIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'hofinitoIntent';
      },
      handle(handlerInput) {
          var speakOutput = 'ok';
           if(typeof autCode === 'undefined'|| autCode === 0){
              const  speakOutput = 'Ottimo lavoro, continua ad allenarti ogni giorno!';
              return handlerInput.responseBuilder
        .speak(speakOutput)
        .reprompt(' ')
        .getResponse();
              
           }else{
      return dialogflowAgentDoc.get()
              .then(doc => {
      let nome = doc.data().nome;
     speakOutput = 'Ottimo lavoro, ' + nome + ', continua ad allenarti ogni giorno!';
   const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(speakOutput)
              .getResponse();
              });
      }
      }
  };


  const HelpIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.HelpIntent';
      },
      handle(handlerInput) {
          const speakOutput = 'Ti ripeto subito quali sono le mie funzioni: posso fornirti delle alternative per alimenti non desiderati, posso darti consigli sugli alimenti da assumere in presenza di alcune patologie e di alcuni disturbi, posso calcolare il tuo indice di massa corporea.';

           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(speakOutput)
              .getResponse();
      }
  };
  const CancelAndStopIntentHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
              && (Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.CancelIntent'
                  || Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.StopIntent');
      },
      handle(handlerInput) {
          const speakOutput = 'A presto!';
           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .getResponse();
      }
  };
  const SessionEndedRequestHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'SessionEndedRequest';
      },
      handle(handlerInput) {
          // Any cleanup logic goes here.
          return handlerInput.responseBuilder.getResponse();
      }
  };

  // The intent reflector is used for interaction model testing and debugging.
  // It will simply repeat the intent the user said. You can create custom handlers
  // for your intents by defining them above, then also adding them to the request
  // handler chain below.
  const IntentReflectorHandler = {
      canHandle(handlerInput) {
          return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest';
      },
      handle(handlerInput) {
          const intentName = Alexa.getIntentName(handlerInput.requestEnvelope);
          const speakOutput = `Scusami, credo di non aver capito. Potresti ripetere?`;

           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(' ')
              .getResponse();
      }
  };

  // Generic error handling to capture any syntax or routing errors. If you receive an error
  // stating the request handler chain is not found, you have not implemented a handler for
  // the intent being invoked or included it in the skill builder below.
  const ErrorHandler = {
      canHandle() {
          return true;
      },
      handle(handlerInput, error) {
          console.log(`~~~~ Error handled: ${error.stack}`);
          const speakOutput = `Scusa, ho riscontrato problemi nella tua richiesta, prova di nuovo.`;

           const BACKGROUND_IMAGE_URL = 'https://lh3.googleusercontent.com/proxy/4-YcpcyLPqy3yETx_wChiImFBZvyJbapKJE3mk54gpmZF6H7lu83VeoPdFNz2z9bIJMdH5JltwQI0PQ0dFs4R2RKDsOPHA_m4HCu7c1BgUGRGII8YjTHFiveCtg',
              TITLE = 'Fit Bot',
              TEXT = speakOutput;
                    let backgroundImage = new Alexa.ImageHelper()
                    .withDescription(TITLE)
                    .addImageInstance(BACKGROUND_IMAGE_URL)
                    .getImage();
            
                  let primaryText = new Alexa.RichTextContentHelper()
                    .withPrimaryText(TEXT)
                    .getTextContent();
            
                  let myTemplate = {
                    type: 'BodyTemplate1',
                    token: 'Welcome',
                    backButton: 'HIDDEN',
                    backgroundImage: backgroundImage,
                    title: TITLE,
                    textContent: primaryText,
                     }
                     
         return handlerInput.responseBuilder
            .addRenderTemplateDirective(myTemplate)
		.speak(speakOutput)
              .reprompt(speakOutput)
              .getResponse();
      }
  };

  // The SkillBuilder acts as the entry point for your skill, routing all request and response
  // payloads to the handlers above. Make sure any new handlers or interceptors you've
  // defined are included below. The order matters - they're processed top to bottom.
  exports.handler = Alexa.SkillBuilders.custom()
      .addRequestHandlers(
          LaunchRequestHandler,
          HelpIntentHandler,  // DA QUI QUELLI CUSTOM
          AutIntentHandler, //GESTORE RISPOSTA CODICE UTENTE
          SostPastaIntentHandler,
          comestaiIntentHandler,
          hofinitoIntentHandler,
          prossimoesercizioIntentHandler,
          fabbisognocaloricoIntentHandler,
          beneIntentHandler,
          numeroIntenHandler,
          allenamentoIntentHandler,
          iniziamoIntentHandler,
          allattamentoIntentHandler,
          maleIntentHandler,
          menopausaIntentHandler,
          anzianiIntentHandler,
          bambiniIntentHandler,
          cosamangiareIntentHandler,
          gravidanzaIntentHandler,
          piacereIntentHandler,
          haifameIntentHandler,
          chiseiIntentHandler,
          quantiannihaiIntentHandler,
          seiirritanteIntentHandler,
          seibellissimoIntentHandler,
          chieiltuobossIntentHandler,
          seiimpegnatoIntentHandler,
          seiunbotIntentHandler,
          seidivertenteIntentHandler,
          seifeliceIntentHandler,
          seiliIntentHandler,
          PesaturaGuestIntentHandler,
          GrazieIntentHandler,
          SostTonnoInScatolaIntentHandler,
          SostZucchineIntentHandler,
          GetPesoIntentHandler,
          AiutoASeguireUnaDietaIntentHandler,
          SostbarBabietoleIntentHandler,
          SostTacchinoIntentHandler,
          VenIntentHandler,
          SostPolloIntentHandler,
          HoFameIntentHandler,
          SostLatteIntentHandler,
          SostMerluzzoIntentHandler,
          SalutoIntentHandler,
          ScoraggiamentoIntentHandler,
          MiSpiegherestiCosaYourDietIntentHandler,
          MarIntentHandler,
          ConsigliIntentHandler,
          SostProsciuttoCrudoIntentHandler,
          SostOrzoIntentHandler,
          TuttaLaDietaIntentHandler,
          InfoSostituzioniIntentHandler,
          DomIntentHandler,
          SostLenticchieIntentHandler,
          SostYogurtIntentHandler,
          AlimentiGasintestinaliIntentHandler,
          ConsiglioNoGlutineIntentHandler,
          LunIntentHandler,
          MangiatoOggiIntentHandler,
          ColesteroloConsigliIntentHandler,
          GonfioreAddomeIntentHandler,
          CosaSaiFareIntentHandler,
          SostFesaTacchinoIntentHandler,
          SostBresaolaIntentHandler,
          GioIntentHandler,
          SostFetteBiscottateIntentHandler,
          NonHoUnaDietaIntentHandler,
          SostGamberiIntentHandler,
          SostVitelloIntentHandler,
          NotAStatementIntentHandler,
          AlimentoAntisonnolenzaIntentHandler,
          KappaIntentHandler,
          MerIntentHandler,
          SostFagioliIntentHandler,
          SostFaveIntentHandler,
          SostSogliolaIntent,
          AlimentiAcneIntentHandler,
          CosaMangioDomaniIntentHandler,
          ConsiglioFerroBassoIntentHandler,
          SabIntentHandler,
          SostRisoIntentHandler,
          LiquidiInfoIntentHandler,
          ConsiglioNoLattosioIntentHandler,
          AlimentoRelaxIntentHandler,
          InsonniaIntentHandler,
          NoIntentHandler,
          NonStoBeneIntentHandler, //FINE CUSTOM
          CancelAndStopIntentHandler,
          SessionEndedRequestHandler,
          IntentReflectorHandler, // make sure IntentReflectorHandler is last so it doesn't override your custom intent handlers
      )
      .addErrorHandlers(
          ErrorHandler,
      )
      .lambda();
